CREATE DATABASE IF NOT EXISTS vintage_bloom;
USE vintage_bloom;

CREATE TABLE produto (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    marca VARCHAR(100),
    tamanho VARCHAR(20) NOT NULL,
    descricao VARCHAR(100) NOT NULL
);


create table usuarios (
    id_usuario int auto_increment primary key,
    cpf varchar(14) NOT NULL,
    nome varchar(255) NOT NULL,
    email varchar (255) NOT NULL,
    senha varchar(60) NOT NULL
);
 SELECT * FROM produto;
