<?php

$host = 'localhost';
$nomeBanco = 'vintage_bloom';
$username = "root";
$password = "";

try{
$conexao = new PDO("mysql:host=$host;
dbname=$nomeBanco;
chatset=UTF8",
$username,
$password
);

$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo"Conexão bem sucedida! <br><hr><br>";


}catch(PDOException $e){

echo"Erro: " . $e->getMessage();

}

?>