<?php

    $requisicao = $_POST['requisicao'];

    switch($requisicao){
        case 'Atualizar' :
            include 'atualizarUsuario.php';
            break;
        case 'Cadastrar':
            include 'cadastroUsuario.php';
            break;
        case 'Consultar':
            include 'consultarUsuario.php';
            break;
        case 'Remover':
            include 'removerUsuario.php';
            break;
        default:
            echo "Ação inválida, por gentileza selecionar uma opção válida.";
            break;
    }

?>