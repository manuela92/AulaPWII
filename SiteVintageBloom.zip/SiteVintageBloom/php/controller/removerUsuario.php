<?php

require_once ('../model/Conexao.php');

$email = $_POST['email'];

if(!empty($email)){

    $sql = "DELETE FROM usuarios WHERE email = :email";


    $requisicao = $conexao->prepare($sql);
    $requisicao->bindParam(':email', $email);
    try{
        $requisicao->execute();
    if ($requisicao->rowCount() > 0) {
        echo "<script>alert('Usuário removido!');
        window.location.href = '../view/cadastro.html'</script>";
    } else {
        echo "<script>alert('Usuário não existe');</script>";
    }
    }catch(PDOException $e){
        echo"Erro ao remover: " . $e->getMessage();
    }

}else{
    echo "Digite um email para remover algum usuário.";
}

?>