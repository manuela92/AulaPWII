<?php

require_once ('../model/Conexao.php');

$email = $_POST['email'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$senha = $_POST['senha'];

if(!empty($email)&&!empty($nome)&&!empty($cpf)&&!empty($senha)){
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    //Instrução DML
    $sql = 'INSERT INTO usuarios (email, cpf, nome, senha) VALUES (:email, :cpf, :nome, :senha)';

    //preparar a inserção de dados no banco
    $requisicao = $conexao->prepare($sql);

    $requisicao->bindParam(':email', $email);
    $requisicao->bindParam(':cpf', $cpf);
    $requisicao->bindParam(':nome', $nome);
    $requisicao->bindParam(':senha', $senhaHash);

    try{
        $requisicao->execute();
        header('Location: ../view/login.html'); 
        exit();
    }catch(PDOException $e){
        echo 'Erro ao cadastrar: '. $e->getMessage();
    }

}else{
    echo '<p style="color:red;"> Preencha todos os campos. </p>';
}

?>