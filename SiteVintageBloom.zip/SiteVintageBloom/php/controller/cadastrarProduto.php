<?php

    require_once ('../model/Conexao.php');

    $nome = $_POST['nome'];
    $preco  = $_POST['preco'];
    $marca = $_POST['marca']; 
    $tamanho = $_POST['tamanho'];
    $descricao = $_POST['descricao']; 



    if(!empty($nome) && !empty($preco) && !empty($marca) && !empty($tamanho) && !empty($descricao)){
        $sql = "INSERT INTO produto (nome, preco, marca, tamanho, descricao) VALUES (:nome, :preco, :marca, :tamanho, :descricao)";

        $requisicao = $conexao->prepare($sql);

        $requisicao->bindParam(':nome', $nome);
        $requisicao->bindParam(':preco', $preco);
        $requisicao->bindParam(':marca', $marca);
        $requisicao->bindParam(':tamanho', $tamanho);
        $requisicao->bindParam(':descricao', $descricao);

        try{
            $requisicao->execute();
            echo 'Produto cadastrado com sucesso!';

        }catch(PDOException $e){
            echo 'Erro ao cadastrar Produto: ' . $e->getMessage();
        }

    }else{
        echo '<p style="color:red;">Preencha corretamente os campos para cadastrar o produto. </p>';
    }

?>