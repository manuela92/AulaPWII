<?php

session_start();

require_once('../model/Conexao.php');

$email = $_POST['email'];
$senha = $_POST['senha'];

if(!empty($email) && !empty($senha)){
    $sql = 'SELECT * FROM usuarios WHERE email = :email';

    $requisicao = $conexao -> prepare($sql);
    $requisicao -> bindParam(':email', $email);
    $requisicao -> execute();

    $usuario = $requisicao -> fetch(PDO::FETCH_ASSOC);

    if($usuario && password_verify($senha, $usuario['senha'])){
        header('Location: ../view/Produtos.html');
        exit();
    }else{
        echo'Email ou senha incorretos';
    }

}else{
    echo'Preencha todos os campos';
}

?> 