<?php

require_once ('../model/Conexao.php');

$email = $_POST['email'];

if(!empty($email)){
    $sql = "SELECT * FROM usuarios WHERE (email) = (:email)";
    $requisicao = $conexao->prepare($sql);
    $requisicao -> bindParam(':email', $email);

    try{
    $requisicao -> execute();
    $usuario = $requisicao->fetch(PDO::FETCH_ASSOC);
    if($usuario){
    echo "<script>
        alert('Nome: " . $usuario['nome'] . "\\nEmail: " . $usuario['email'] . "');
    </script>";
    }else {
        echo "<script>
            alert('Usuário não existe');
        </script>";
    }
    }catch(PDOException $e){
        echo'Erro ao localizar usuário' . $e -> getMessage();
    }


}else{
    echo'Insira um e-mail válido';
}
?>